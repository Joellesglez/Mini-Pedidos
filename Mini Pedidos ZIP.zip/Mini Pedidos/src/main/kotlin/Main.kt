// Paso 1: enum de estados
enum class EstadoPedido {
     CREADO, EN_PREPARACION ,  LISTO, ENTREGADO, CANCELADO;

    fun esFinalizado(): Boolean = this == ENTREGADO || this == CANCELADO
}

// Paso 2: interfaces
interface Cobrable {
    fun total(): Double
    fun cobrar(): Boolean
}

interface Descontable {
    fun aplicarDescuento(): Double
}

// Soporte: ítems del pedido
data class Item(
    val nombre: String,
    val precio: Double,
    val cantidad: Int
)

// Paso 3: clase Pedido
class Pedido private constructor(
    val id: Int,
    val cliente: String,
    val items: List<Item>,
    var estado: EstadoPedido,
    private val vip: Boolean = false
) : Cobrable, Descontable {

    override fun total(): Double {
        return items.sumOf { it.precio * it.cantidad }
    }

    override fun aplicarDescuento(): Double {
        return if (vip) total() * 0.9 else total()
    }

    override fun cobrar(): Boolean {
        return (if (estado == EstadoPedido.  LISTO) {
            estado = EstadoPedido.  ENTREGADO
                    true
        } else {
            false
        }) as Boolean
    }

    fun avanzarEstado(): Boolean {
        return when (estado) {
            EstadoPedido.CREADO -> {
                estado = EstadoPedido.EN_PREPARACION
                true
            }
            EstadoPedido.EN_PREPARACION -> {
                estado = EstadoPedido.LISTO
                true
            }
            EstadoPedido.LISTO -> {
                false
            }
            EstadoPedido.ENTREGADO,
            EstadoPedido.CANCELADO -> false
        }
    }

    companion object {
        private var sec = 0
        fun crear(cliente: String, items: List<Item>, vip: Boolean = false): Pedido {
            require(items.isNotEmpty()) { "El pedido debe tener al menos un ítem." }
            require(items.all { it.cantidad > 0 }) { "Las cantidades deben ser > 0." }
            val nuevoId = ++sec
            return Pedido(
                id = nuevoId,
                cliente = cliente,
                items = items,
                estado = EstadoPedido.CREADO,
                vip = vip
            )
        }

        fun desdeTexto(texto: String, vip: Boolean = false): Pedido {
            val partes = texto.split(":")
            require(partes.size == 2) { "Formato inválido" }
            val cliente = partes[0].trim()
            val itemsStr = partes[1].split(",")
            val items = itemsStr.map {
                val (nombre, detalle) = it.split("=")
                val (cant, precio) = detalle.split("x")
                Item(nombre.trim(), precio.trim().toDouble(), cant.trim().toInt())
            }
            return crear(cliente, items, vip)
        }
    }

    override fun toString(): String {
        return buildString {
            append("Pedido(id=$id, cliente='$cliente'")
            if (vip) append(" [VIP]")
            append(", estado=$estado, total=%.2f)".format(aplicarDescuento()))
        }
    }
}

// Paso 5: demo
fun main() {
    val pedido1 = Pedido.crear("Silvia", listOf(Item("Café", 1.5, 2), Item("Pulguita", 3.0, 1)))
    val pedido2 = Pedido.crear("Ana", listOf(Item("Té", 1.2, 1)), vip = true)
    val pedido3 = Pedido.desdeTexto("Amador: Sandwich=2x3.0, Café=1x1.5")

    pedido1.avanzarEstado()
    pedido1.avanzarEstado() // LISTO

    println("¿Pedido3 cobrado? ${pedido3.cobrar()}")
    println("¿Pedido1 cobrado? ${pedido1.cobrar()}")

    pedido2.avanzarEstado()
    pedido2.avanzarEstado() // LISTO
    println("¿Pedido2 cobrado? ${pedido2.cobrar()}")

    println("\nResumen:")
    println(pedido1)
    println(pedido2)
    println(pedido3)
}
